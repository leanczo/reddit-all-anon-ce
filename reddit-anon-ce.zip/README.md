# reddit-all-anon-ce

This extension for google chrome hide all usernames from Reddit
